import { useEmpresaFaq } from "../context/dtsEmpContext.jsx";
import { useEffect } from "react";

function Contacto() {
  const { empresa, getEmpresa } = useEmpresaFaq();

  useEffect(() => {
    getEmpresa();
  }, []);

  return (
    <div className="container mt-5">
      <div className="nuevo-apartado mb-4 p-5">
        <h2 className="text-center">Contacto</h2>
        <form>
          <div className="mb-3">
            <label htmlFor="nombre" className="form-label">Nombre</label>
            <input type="text" className="form-control" id="nombre" placeholder="Tu nombre" />
          </div>
          <div className="mb-3">
            <label htmlFor="correo" className="form-label">Correo</label>
            <input type="email" className="form-control" id="correo" placeholder="tu@correo.com" />
          </div>
          <div className="mb-3">
            <label htmlFor="telefono" className="form-label">Teléfono</label>
            <input type="tel" className="form-control" id="telefono" placeholder="Tu teléfono" />
          </div>
          <div className="mb-3">
            <label htmlFor="comentario" className="form-label">Comentario</label>
            <textarea className="form-control" id="comentario" rows="4" placeholder="Escribe tu mensaje"></textarea>
          </div>
          <button type="submit" className="btn bg__fondo text-white fw-bold">Enviar</button>
        </form>
        <div className="mt-5 border-top text-center">
          <h2 className="mt-4">Atención a Clientes</h2>
          <p><strong>Teléfono:</strong> {empresa?.telefono || "No disponible"}</p>
        </div>
      </div>

      <div className="nuevo-apartado mt-4 p-5">
        <h2>Encuéntranos</h2>
        <p>Visítanos en nuestra tienda o centro de atención:</p>
        <div style={{ width: "100%", height: "300px" }}>
          <iframe
            width="100%"
            height="100%"
            frameBorder="0"
            scrolling="no"
            marginHeight="0"
            marginWidth="0"
            src={`https://maps.google.com/maps?q=${empresa?.ubicacion?.lat},${empresa?.ubicacion?.lon}&t=&z=13&ie=UTF8&iwloc=&output=embed`}
          ></iframe>
        </div>
      </div>
    </div>
  );
}

export default Contacto;