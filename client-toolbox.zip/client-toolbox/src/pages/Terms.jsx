import React, { useEffect } from "react";
import { useEmpresaFaq } from "../context/dtsEmpContext";

const Terms = () => {
  const { tyc, getTyC } = useEmpresaFaq();

  useEffect(() => {
    getTyC();
  }, []);

  return (
    <div className="container mt-5">
      <section className="py-5">
        <h2 className="text-form1 fw-bold mb-4">Términos y Condiciones</h2>
        {tyc.length > 0 ? (
          tyc.map((termino) => (
            <div key={termino._id}>
              <p className="lead text-muted">{termino.contenido}</p>
              <p className="text-muted">
                📅 Última actualización:{" "}
                {new Date(termino.fechaCreacion).toLocaleDateString("es-ES", {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </p>
              <hr />
            </div>
          ))
        ) : (
          <p className="text-muted">No hay términos y condiciones registrados.</p>
        )}
        <p className="text-muted">
          Si tienes alguna duda, contáctanos a través de nuestro soporte técnico.
        </p>
      </section>
    </div>
  );
};

export default Terms;
