import React, { useEffect, useState } from 'react';
import mqtt from 'mqtt';
import './VentanaCtrl.css';

const MQTT_BROKER = "wss://584812d491644e289c0361eee4ae4aa5.s1.eu.hivemq.cloud:8884/mqtt"; // Usamos WebSocket para conexión web
const MQTT_OPTIONS = {
  username: "Angel19",
  password: "iS4@vJiy@Pfkt9e",
  clientId: "reactClient-" + Math.random().toString(16).substr(2, 8),
};

const VentanaCtrl = () => {
  const [client, setClient] = useState(null);
  const [isConnected, setIsConnected] = useState(false);
  const [sensorData, setSensorData] = useState({
    temperatura: '--',
    humedad: '--',
    calidad_aire: '--',
    lluvia: '--',
    estado: '--',
    seguro: '--'
  });

  useEffect(() => {
    const mqttClient = mqtt.connect(MQTT_BROKER, MQTT_OPTIONS);

    mqttClient.on('connect', () => {
      console.log('Conectado al broker MQTT');
      setIsConnected(true);
      mqttClient.subscribe("ventana/+", (err) => {
        if (err) {
          console.error("Error en la suscripción", err);
        }
      });
    });

    mqttClient.on('error', (err) => {
      console.error('Error de conexión: ', err);
      mqttClient.end();
    });

    mqttClient.on('message', (topic, message) => {
      const msg = message.toString();
      console.log(topic, msg);
      switch (topic) {
        case "ventana/temperatura":
          setSensorData(prev => ({ ...prev, temperatura: msg }));
          break;
        case "ventana/humedad":
          setSensorData(prev => ({ ...prev, humedad: msg }));
          break;
        case "ventana/calidad_aire":
          setSensorData(prev => ({ ...prev, calidad_aire: msg }));
          break;
        case "ventana/lluvia":
          setSensorData(prev => ({ ...prev, lluvia: msg }));
          break;
        case "ventana/estado":
          setSensorData(prev => ({ ...prev, estado: msg }));
          break;
        case "ventana/seguro":
          setSensorData(prev => ({ ...prev, seguro: msg }));
          break;
        default:
          break;
      }
    });

    setClient(mqttClient);

    return () => {
      if (mqttClient) mqttClient.end();
    };
  }, []);

  const sendCommand = (command) => {
    if (client && isConnected) {
      client.publish("ventana/control", command);
      console.log("Comando enviado:", command);
    }
  };

  const estadoVentana = sensorData.estado === 'abierta' ? 'Abierta' : 'Cerrada';

  return (
    <div className="main-container">
      <h1 className="header-title">Control Inteligente IoT</h1>
      <div className="card-wrapper">
        {/* Panel de Control */}
        <div className="control-card">
          <h3>Control de Ventana</h3>
          <button onClick={() => sendCommand("a")} className="action-btn">Abrir Ventana</button>
          <button onClick={() => sendCommand("c")} className="action-btn">Cerrar Ventana</button>
          <p>Estado de la Ventana: {estadoVentana}</p> {/* Mostrar si está abierta o cerrada */}
        </div>

        {/* Estado del Seguro */}
        <div className="control-card">
          <h3>Estado del Seguro</h3>
          <p>{sensorData.seguro}</p>
          <button onClick={() => sendCommand("d")} className="action-btn">Desbloquear</button>
          <button onClick={() => sendCommand("b")} className="action-btn">Bloquear</button>
        </div>

        {/* Datos del Sensor */}
        <div className="control-card">
          <h3>Datos del Sensor</h3>
          <p>Temperatura: {sensorData.temperatura} °C</p>
          <p>Humedad: {sensorData.humedad} %</p>
          <p>Calidad de Aire: {sensorData.calidad_aire}</p>
          <p>Lluvia: {sensorData.lluvia}</p>
        </div>
      </div>

      {/* Información Adicional */}
      <div className="device-info">
        <h3>Información del Dispositivo</h3>
        <p>Código de Dispositivo: 12345-IOT</p>
        <p>Estado de Conexión: {isConnected ? 'Conectado' : 'Desconectado'}</p>
        <p>Dirección IP: 192.168.1.10</p>
        <p>Versión del Sistema: 1.0.3</p>
      </div>
    </div>
  );
};

export default VentanaCtrl;
