import React, { useEffect, useState } from 'react'; 
import { useParams, useNavigate } from 'react-router-dom';
import { CgAdd, CgInpicture, CgTrash } from "react-icons/cg"; 
import Swal from 'sweetalert2';  // Importa SweetAlert2
import { useSincronizacion } from "../../context/SincronizacionContext.jsx"; // Importa el contexto de sincronización

function MenuVentana() {
  const { email } = useParams(); // Recibimos el email desde la URL
  const { sincronizaciones, getSincronizaciones } = useSincronizacion(); // Llamamos al contexto de sincronización
  const [loading, setLoading] = useState(true);

  // Obtener las sincronizaciones cuando el componente se monta
  useEffect(() => {
    if (email) {
      getSincronizaciones(email);
    }
    setLoading(false);
  }, [email, getSincronizaciones]);

  // Función para mostrar la alerta y obtener los datos del formulario
  const handleAddDevice = () => {
    Swal.fire({
      title: 'Agregar Ventana',
      html: `
        <input id="codigoVentana" class="swal2-input" placeholder="Código de la ventana" />
        <input id="nombreVentana" class="swal2-input" placeholder="Nombre de la ventana" />
      `,
      focusConfirm: false,
      preConfirm: () => {
        const codigo = document.getElementById('codigoVentana').value;
        const nombre = document.getElementById('nombreVentana').value;

        if (!codigo || !nombre) {
          Swal.showValidationMessage('Por favor ingresa un código y un nombre');
          return false;
        }

        // Aquí llamamos a la función para sincronizar
        handleSynchronize(codigo, nombre);
      }
    });
  };

  // Lógica para sincronizar
  const handleSynchronize = (codigo, nombre) => {
    console.log(`Sincronizando ventana con código: ${codigo} y nombre: ${nombre}`);
    console.log("Email del usuario:", email); // El email del usuario ya está disponible

    // Llamamos a la función addSincronizacion del contexto para agregar la sincronización
    addSincronizacion(email, codigo, nombre);

    Swal.fire('Sincronización Exitosa', `Ventana ${nombre} sincronizada con éxito!`, 'success');
  };

  return (
    <div className="nuevo-apartado">
      <div className="text-end mb-4 card__icon--border-bottom">
        <CgAdd size={35} onClick={handleAddDevice} /> {/* Agregar ventana */}
      </div>

      <div className="row row-cols-2">
        {/* Si hay sincronizaciones, mostramos las tarjetas */}
        {loading ? (
          <p>Cargando sincronizaciones...</p>
        ) : sincronizaciones.length > 0 ? (
          sincronizaciones.map((sincronizacion) => (
            <div key={sincronizacion._id} className="col mb-4">
              <div className="card shadow border-0">
                <div className="card-body">
                  <div className="d-flex justify-content-between mb-2">
                    <CgInpicture size={30} />
                    <button className="btn p-0 border-0" onClick={() => alert('Acción eliminar')}>
                      <CgTrash size={30} />
                    </button>
                  </div>

                  <h5 className="card-title mb-1">{sincronizacion.nombre}</h5>
                  <p className="card-text text-muted">Conectado</p>
                </div>
              </div>
            </div>
          ))
        ) : (
          <p className="text-center">No tienes ventanas sincronizadas.</p>
        )}
      </div>
    </div>
  );
}

export default MenuVentana;
