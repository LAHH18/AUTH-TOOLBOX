import { useForm } from "react-hook-form";
import { useAuth } from "../context/AuthContext";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";

function RegisterPage() {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const { signup, isAuthenticated, errors: registerErrors } = useAuth();

  const navigate = useNavigate();
  
  useEffect(() => {
    if (isAuthenticated) navigate('/');
  }, [isAuthenticated]);

  const onSubmit = handleSubmit(async (values) => {
    signup(values);
  });

  return (
    <div className="container mt-5 mb-5 bg-light rounded shadow-lg p-4" style={{ maxWidth: "600px" }}>
      <h2 className="text-center fw-bold pt-3">Registro de Usuario</h2>
      {Array.isArray(registerErrors) && registerErrors.map((error, i) => (
        <div className="bg-danger text-center p-2 text-white" key={i}>
          {error}
        </div>
      ))}


      <form onSubmit={onSubmit} className="mt-4">
        {/* Nombres */}
        <div className="mb-3">
          <label htmlFor="nombres" className="form-label">Nombres</label>
          <input type="text" id="nombres" className="form-control" placeholder="Ingresa tus nombres" {...register("name.nombres", { required: true })} />
          {errors.username && <p className="text-danger">Usuario requerido</p>}
        </div>

        {/* Usuario */}
        <div className="mb-3">
          <label htmlFor="username" className="form-label">Usuario</label>
          <input type="text" className="form-control" placeholder="Ingresa tu usuario" {...register("username", { required: true })} />
        </div>

        {/* Correo Electrónico */}
        <div className="mb-3">
          <label htmlFor="email" className="form-label">Correo Electrónico</label>
          <input type="email" className="form-control" placeholder="Ingresa tu correo electrónico" {...register("email", { required: true })} />
        </div>

        {/* Contraseña */}
        <div className="mb-3">
          <label htmlFor="contra" className="form-label">Contraseña</label>
          <input type="password" className="form-control" placeholder="Ingresa tu contraseña" {...register("contra", { required: true })} />
        </div>

        {/* Confirmar Contraseña */}
        <div className="mb-3">
          <label htmlFor="confirmContra" className="form-label">Confirmar Contraseña</label>
          <input type="password" className="form-control" placeholder="Confirma tu contraseña" {...register("confirmContra", { required: true })} />
        </div>

        {/* Pregunta de Seguridad */}
        <div className="mb-3">
          <label htmlFor="pregunta" className="form-label">Pregunta de Seguridad</label>
          <select className="form-select" {...register("pregunta", { required: true })}>
            <option value="">Selecciona una pregunta</option>
            <option value="¿Cuál es tu color favorito?">¿Cuál es tu color favorito?</option>
            <option value="¿Cuál es el nombre de tu primera mascota?">¿Cuál es el nombre de tu primera mascota?</option>
            <option value="¿Cuál es tu comida favorita?">¿Cuál es tu comida favorita?</option>
          </select>
        </div>

        {/* Respuesta */}
        <div className="mb-3">
          <label htmlFor="respuesta" className="form-label">Respuesta</label>
          <input type="text" className="form-control" placeholder="Ingresa la respuesta" {...register("respuesta", { required: true })} />
        </div>

        <button type="submit" className="btn w-100 fw-bold boton">Registrar</button>
      </form>

      <div className="mt-3 text-center">
        <Link to="/login" className="text-decoration-none text-primary">¿Ya tienes cuenta?</Link>
      </div>
    </div>
  );
}

export default RegisterPage;
