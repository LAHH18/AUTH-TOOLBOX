import React, { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext.jsx";
import { useNavigate } from "react-router-dom";
import { useProducts } from "../context/ProductsContext.jsx";
import { useFavorites } from "../context/FavoritosContext.jsx"; 
import Card from "../components/Card.jsx";
import { Link } from "react-router-dom";

function HomePage() {
  const { getProducts, products } = useProducts();
  const { getFavorites, addFavorite, removeFavorite, favorites, setFavorites } = useFavorites();
  const { user, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 9;
  const email = user?.email;

  useEffect(() => {
    getProducts();
    if (isAuthenticated && email) {
      getFavorites(email);
    } else {
      setFavorites([]);
    }
  }, [isAuthenticated, email]);

  const handleFavorite = async (productId) => {
    if (!isAuthenticated) {
      navigate("/login");
      return;
    }

    if (!productId) {
      alert("Error: El producto no tiene un código válido.");
      return;
    }

    try {
      const isFav = favorites.some((fav) => fav.producto.codigo === productId);

      if (isFav) {
        await removeFavorite(email, productId);
      } else {
        await addFavorite(email, productId);
      }

      getFavorites(email);
    } catch (error) {
      alert(error.response?.data?.message || "Error al gestionar favoritos.");
    }
  };

  const indexOfLastProduct = currentPage * itemsPerPage;
  const indexOfFirstProduct = indexOfLastProduct - itemsPerPage;
  const currentProducts = products.slice(indexOfFirstProduct, indexOfLastProduct);
  const totalPages = Math.ceil(products.length / itemsPerPage);
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  return (
    <div>
      <div className="container">
      <div id="welcomeCarousel" className="carousel slide mb-5" data-bs-ride="carousel">
          <div className="carousel-inner mt-5">
            <div className="carousel-item active">
              <div className="container bg-light rounded shadow-sm p-4">
                <div className="text-center">
                  <h2 className="bd__text mb-3">¡Bienvenido a ToolBox!</h2>
                  <p className="text-muted mb-4">Encuentra las mejores herramientas y productos para tus proyectos.</p>
                  <p className="mb-0">
                    <Link to="/menuVent" className="text-decoration-none text-primary fw-bold hover-underline-animation">
                      Ventana
                    </Link>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>


        <div className="p-5 row m__vacio--cards">
          {currentProducts.map((product) => {
            const isFavorite = favorites.some((fav) => fav.producto.codigo === product.codigo);
            return (
              <div key={product._id} className="col-12 col-sm-6 col-md-4 col-lg-4">
                <Card
                  imagen={product.imagenes.img1}
                  titulo={product.nombre}
                  descripcion={product.descripcion}
                  precio={product.precio}
                  verProduct={() => navigate(`/product/${product._id}`)}
                  isFavorite={isFavorite} 
                  productoCodigo={product.codigo} 
                  handleFavorite={handleFavorite} 
                />
              </div>
            );
          })}
        </div>

        {products.length > itemsPerPage && (
          <nav>
            <ul className="pagination justify-content-center">
              <li className={`page-item ${currentPage === 1 ? "disabled" : ""}`}>
                <button className="page-link" onClick={() => paginate(currentPage - 1)} disabled={currentPage === 1}>
                  Anterior
                </button>
              </li>
              {[...Array(totalPages).keys()].map((number) => (
                <li key={number + 1} className={`page-item ${currentPage === number + 1 ? "active" : ""}`}>
                  <button className="page-link" onClick={() => paginate(number + 1)}>
                    {number + 1}
                  </button>
                </li>
              ))}
              <li className={`page-item ${currentPage === totalPages ? "disabled" : ""}`}>
                <button className="page-link" onClick={() => paginate(currentPage + 1)} disabled={currentPage === totalPages}>
                  Siguiente
                </button>
              </li>
            </ul>
          </nav>
        )}
      </div>
    </div>
  );
}

export default HomePage;
