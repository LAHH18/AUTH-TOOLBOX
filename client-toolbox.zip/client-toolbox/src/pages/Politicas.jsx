import React, { useEffect } from "react";
import { useEmpresaFaq } from "../context/dtsEmpContext";

const Politicas = () => {
  const { politicas, getPoliticas } = useEmpresaFaq();

  useEffect(() => {
    getPoliticas();
  }, []);

  return (
    <div className="container mt-5">
      <section className="py-5">
        <h2 className="text-form1 fw-bold mb-4">Política de Privacidad</h2>
        {politicas.length > 0 ? (
          politicas.map((politica) => (
            <div key={politica._id}>
              <p className="lead text-muted">{politica.contenido}</p>
              <p className="text-muted">
                📅 Última actualización:{" "}
                {new Date(politica.fechaCreacion).toLocaleDateString("es-ES", {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </p>
              <hr />
            </div>
          ))
        ) : (
          <p className="text-muted">No hay políticas registradas.</p>
        )}
        <p className="text-muted">
          Para más detalles, consulta nuestra política completa o contáctanos si tienes dudas.
        </p>
      </section>
    </div>
  );
};

export default Politicas;
