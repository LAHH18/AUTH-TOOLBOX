import { useForm } from "react-hook-form";
import { useAuth } from "../context/AuthContext";
import { Link, useNavigate } from "react-router-dom";
import React, { useEffect } from 'react';

function LoginPage() {
  const navigate = useNavigate();

  // Extrae los métodos de react-hook-form
  const { register, handleSubmit, formState: { errors } } = useForm();

  // Extrae los datos del contexto de autenticación
  const { isAuthenticated, signin, errors: signinErrors, user } = useAuth();

  // LoginPage.jsx (fragmento)
  useEffect(() => {
    if (isAuthenticated) {
      if (user.rol === 1) {
        navigate('/HomePagePriv');
      } else if(user.rol === 3) {
        navigate('/HomeEmpleados');
      } else {
        navigate('/');
      }
    }
  }, [isAuthenticated, navigate, user]);


  const togglePasswordVisibility = () => {
    const passwordInput = document.getElementById("password");
    if (passwordInput) {
      passwordInput.type =
        passwordInput.type === "password" ? "text" : "password";
    }
  };

  const onSubmit = handleSubmit((data) => {
    signin(data);
  });

  return (
    <div
      className="d-flex justify-content-center align-items-center"
      style={{ minHeight: "100vh", backgroundColor: "#E9EEF3" }}
    >
      <div
        className="card shadow p-4"
        style={{ maxWidth: "400px", width: "100%", borderRadius: "8px" }}
      >
        <h2 className="text-center mb-4 fw-bold">Iniciar Sesión</h2>
        {
          signinErrors.map((error, i) =>
            <div className="bg-danger text-center p-2 text-white" key={i}>
              {error}
            </div>
          )
        }
        <form onSubmit={onSubmit}>
          <div className="mb-3">
            <label htmlFor="username" className="form-label fw-semibold">
              Correo:
            </label>
            <input
              type="email"
              className="form-control"
              id="email"
              placeholder="Ingresa tu usuario"
              {...register("email", { required: true })}
            />
          </div>
          {errors.email && (
            <div className="bg-danger text-center p-2 text-white">
              El correo es requerido
            </div>
          )}
          <div className="mb-3">
            <label htmlFor="password" className="form-label fw-semibold">
              Contraseña:
            </label>
            <div className="input-group">
              <input
                type="password"
                className="form-control"
                id="password"
                placeholder="Ingresa tu contraseña"
                {...register("contra", { required: true })}
              />
              <span className="input-group-text">
                <input
                  type="checkbox"
                  id="showPassword"
                  onClick={togglePasswordVisibility}
                  style={{ cursor: "pointer" }}
                />
                <label
                  htmlFor="showPassword"
                  className="ms-1 mb-0"
                  style={{ cursor: "pointer" }}
                >
                  Mostrar
                </label>
              </span>
            </div>
            {errors.contra && (
              <div className="bg-danger text-center p-2 text-white">
                La contraseña es requerida
              </div>
            )}
          </div>
          <button
            type="submit"
            className="btn fw-bold boton"
            style={{ width: "100%" }}>
            Iniciar
          </button>
        </form>
        <div className="mt-4 d-flex justify-between">
          <p className="text-decoration-none me-3 text-primary">
            <Link to="/products">¿Has olvidado tu contraseña?</Link>
          </p>
          <p className="text-decoration-none me-3 text-primary">
            <Link to="/register">Registrarse</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
