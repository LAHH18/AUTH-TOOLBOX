import React, { useEffect } from "react";
import { useEmpresaFaq } from "../../context/dtsEmpContext.jsx";
import { Link } from "react-router-dom";
import Swal from "sweetalert2";

function ViewFAQ() {
  const { preguntas, getPreguntas, deletePregunta } = useEmpresaFaq();

  useEffect(() => {
    getPreguntas();
  }, []);

  const handleDelete = (id) => {
    Swal.fire({
      title: "¿Estás seguro?",
      text: "Esta acción eliminará la pregunta permanentemente.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#3085d6",
      confirmButtonText: "Sí, eliminar",
      cancelButtonText: "Cancelar",
    }).then((result) => {
      if (result.isConfirmed) {
        deletePregunta(id);
        Swal.fire("Eliminado", "La pregunta ha sido eliminada.", "success");
      }
    });
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center">Gestión de Preguntas Frecuentes</h2>
      <div className="text-end mb-3">
        <Link to="/crtFAQ" className="btn bg__fond_form text-white fw-bold">
          Agregar Pregunta
        </Link>
      </div>
      <table className="table table-striped table-hover">
        <thead className="table-dark">
          <tr>
            <th>Pregunta</th>
            <th>Respuesta</th>
            <th>Estado</th>
            <th>Operaciones</th>
          </tr>
        </thead>
        <tbody>
          {Array.isArray(preguntas) && preguntas.length > 0 ? (
            preguntas.map((faq) => (
              <tr key={faq._id}>
                <td>{faq.pregunta?.slice(0, 40) || "Sin pregunta"}</td>
                <td>{faq.respuesta?.slice(0, 60) || "Sin respuesta"}</td>
                <td>{faq.estado ? "Activo" : "Inactivo"}</td>
                <td>
                  <Link to={`/edtFAQ/${faq._id}`} className="btn btn-warning btn-sm me-2">
                    Editar
                  </Link>
                  <button onClick={() => handleDelete(faq._id)} className="btn btn-danger btn-sm">
                    Eliminar
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="4" className="text-center">No hay preguntas registradas.</td>
            </tr>
          )}
        </tbody>

      </table>
    </div>
  );
}

export default ViewFAQ;
