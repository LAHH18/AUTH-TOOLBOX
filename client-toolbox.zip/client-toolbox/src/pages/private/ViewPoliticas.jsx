import { useEffect } from "react";
import { Link } from "react-router-dom";
import { useEmpresaFaq } from "../../context/dtsEmpContext.jsx";
import Swal from "sweetalert2";

function ViewPoliticas() {
  const { politicas, getPoliticas, deletePolitica } = useEmpresaFaq();

  useEffect(() => {
    getPoliticas();
  }, []);

  const handleDelete = async (id) => {
    const result = await Swal.fire({
      title: "¿Estás seguro?",
      text: "Esta acción no se puede deshacer.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#3085d6",
      confirmButtonText: "Sí, eliminar",
      cancelButtonText: "Cancelar",
    });

    if (result.isConfirmed) {
      await deletePolitica(id);
      Swal.fire("Eliminado", "La política ha sido eliminada.", "success");
      getPoliticas();
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center">Lista de Políticas</h2>
      <div className="text-end mb-3">
        <Link to="/crtPoliticas" className="btn bg__fond_form text-white fw-bold">Agregar Nueva</Link>
      </div>
      <table className="table table-bordered shadow">
        <thead className="table-dark text-center">
          <tr>
            <th>Contenido</th>
            <th>Fecha de Creación</th>
            <th>Operaciones</th>
          </tr>
        </thead>
        <tbody>
          {politicas.length > 0 ? (
            politicas.map((politica) => (
              <tr key={politica._id}>
                <td>
                {politica.contenido.length > 75
                  ? politica.contenido.slice(0,75) + "..."
                  : politica.contenido
                }
                </td>
                <td>{new Date(politica.fechaCreacion).toLocaleDateString()}</td>
                <td>
                  <Link to={`/edtPoliticas/${politica._id}`} className="btn btn-warning mx-2">Editar</Link>
                  <button onClick={() => handleDelete(politica._id)} className="btn btn-danger">Eliminar</button>
                </td>
              </tr>
            ))
          ) : (
            <tr><td colSpan="3">No hay políticas registradas</td></tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

export default ViewPoliticas;
