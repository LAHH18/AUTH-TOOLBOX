import React, { useEffect, useState } from "react";
import { useEmpresaFaq } from "../../context/dtsEmpContext.jsx";
import Swal from "sweetalert2";

const EditEmpresa = () => {
  const { empresa, getEmpresa, updateEmpresa } = useEmpresaFaq();
  const [formData, setFormData] = useState({
    nombre: "",
    telefono: "",
    ubicacion: {
      calle: "",
      colonia: "",
      ciudad: "",
      estado: "",
      codigoPostal: "",
    },
    redes: {
      facebook: "",
      twitter: "",
      instagram: "",
    },
  });

  const [misionVision, setMisionVision] = useState({
    mision: "",
    imgMision: "",
    vision: "",
    imgVision: "",
  });

  useEffect(() => {
    getEmpresa();
  }, []);

  useEffect(() => {
    if (empresa) {
      setFormData({
        nombre: empresa.nombre,
        telefono: empresa.telefono,
        ubicacion: empresa.ubicacion || {},
        redes: empresa.redes || {},
      });

      setMisionVision({
        mision: empresa.mision || "",
        imgMision: empresa.imgMision || "",
        vision: empresa.vision || "",
        imgVision: empresa.imgVision || "",
      });
    }
  }, [empresa]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleNestedChange = (e, section) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [section]: {
        ...formData[section],
        [name]: value,
      },
    });
  };

  const handleMisionVisionChange = (e) => {
    const { name, value } = e.target;
    setMisionVision({
      ...misionVision,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await updateEmpresa({ ...formData, ...misionVision });
      Swal.fire({
        title: "¡Éxito!",
        text: "Los datos de la empresa han sido actualizados correctamente.",
        icon: "success",
        confirmButtonText: "Aceptar",
      });
    } catch (error) {
      console.error("Error al actualizar la empresa:", error);
      Swal.fire({
        title: "¡Error!",
        text: "Hubo un problema al actualizar los datos.",
        icon: "error",
        confirmButtonText: "Intentar de nuevo",
      });
    }
  };

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-10">
          {/* Formulario 1: Datos Generales */}
          <div className="card shadow-lg mb-4">
            <div className="card-header text-center bg__fond_form text-white">
              <h2 className="fw-bold">Editar Datos de la Empresa</h2>
            </div>
            <div className="card-body">
              <form onSubmit={handleSubmit} className="p-4">
                {/* Nombre y Teléfono */}
                <div className="mb-3">
                  <label className="form-label fw-semibold">Nombre de la empresa:</label>
                  <input type="text" className="form-control" name="nombre" value={formData.nombre} onChange={handleChange} />
                </div>
                <div className="mb-3">
                  <label className="form-label fw-semibold">Teléfono:</label>
                  <input type="text" className="form-control" name="telefono" value={formData.telefono} onChange={handleChange} />
                </div>

                {/* Ubicación */}
                <h4 className="mt-4 form__titulo">Ubicación</h4>
                <div className="row">
                  {["calle", "colonia", "ciudad", "estado", "codigoPostal"].map((field, index) => (
                    <div className={`col-md-${field === "codigoPostal" ? "4" : "6"}`} key={index}>
                      <div className="mb-3">
                        <label className="form-label fw-semibold">{field.charAt(0).toUpperCase() + field.slice(1)}:</label>
                        <input type="text" className="form-control" name={field} value={formData.ubicacion[field] || ""} onChange={(e) => handleNestedChange(e, "ubicacion")} />
                      </div>
                    </div>
                  ))}
                </div>

                {/* Redes Sociales */}
                <h4 className="mt-4 form__titulo">Redes Sociales</h4>
                <div className="row">
                  {["facebook", "twitter", "instagram"].map((network, index) => (
                    <div className="col-md-4" key={index}>
                      <div className="mb-3">
                        <label className="form-label fw-semibold">{network.charAt(0).toUpperCase() + network.slice(1)}:</label>
                        <input type="text" className="form-control" name={network} value={formData.redes[network] || ""} onChange={(e) => handleNestedChange(e, "redes")} />
                      </div>
                    </div>
                  ))}
                </div>

                {/* Botón de guardar */}
                <div className="text-center mt-4">
                  <button type="submit" className="btn text-white fw-bold bg__fondo px-4 py-2">
                    Guardar Cambios
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Formulario 2: Misión y Visión */}
          <div className="card shadow-lg">
            <div className="card-header text-center bg__fond_form text-white">
              <h2 className="fw-bold">Editar Misión y Visión</h2>
            </div>
            <div className="card-body">
              <form onSubmit={handleSubmit} className="p-4">
                <div className="row">
                  {/* Misión */}
                  <div className="col-md-6">
                    <h5 className="fw-bold">Misión</h5>
                    <div className="mb-3">
                      <label className="form-label fw-semibold">Descripción:</label>
                      <textarea className="form-control" name="mision" value={misionVision.mision} onChange={handleMisionVisionChange} />
                    </div>
                    <div className="mb-3">
                      <label className="form-label fw-semibold">Imagen URL:</label>
                      <input type="text" className="form-control" name="imgMision" value={misionVision.imgMision} onChange={handleMisionVisionChange} />
                    </div>
                    {misionVision.imgMision && <img src={misionVision.imgMision} alt="Misión" className="img-fluid rounded shadow-lg mb-3" style={{ maxHeight: "150px" }} />}
                  </div>

                  {/* Visión */}
                  <div className="col-md-6">
                    <h5 className="fw-bold">Visión</h5>
                    <div className="mb-3">
                      <label className="form-label fw-semibold">Descripción:</label>
                      <textarea className="form-control" name="vision" value={misionVision.vision} onChange={handleMisionVisionChange} />
                    </div>
                    <div className="mb-3">
                      <label className="form-label fw-semibold">Imagen URL:</label>
                      <input type="text" className="form-control" name="imgVision" value={misionVision.imgVision} onChange={handleMisionVisionChange} />
                    </div>
                    {misionVision.imgVision && <img src={misionVision.imgVision} alt="Visión" className="img-fluid rounded shadow-lg mb-3" style={{ maxHeight: "150px" }} />}
                  </div>
                </div>

                <div className="text-center mt-4">
                  <button type="submit" className="btn text-white fw-bold bg__fondo px-4 py-2">
                    Guardar Cambios
                  </button>
                </div>
              </form>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default EditEmpresa;
