import { useEffect } from "react";
import { Link } from "react-router-dom";
import { useEmpresaFaq } from "../../context/dtsEmpContext.jsx";
import Swal from "sweetalert2";

function ViewTyC() {
  const { tyc, getTyC, deleteTyC } = useEmpresaFaq();

  useEffect(() => {
    getTyC();
  }, []);

  const handleDelete = async (id) => {
    Swal.fire({
      title: "¿Estás seguro?",
      text: "Esta acción eliminará el TyC permanentemente.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Sí, eliminar",
      cancelButtonText: "Cancelar",
    }).then(async (result) => {
      if (result.isConfirmed) {
        await deleteTyC(id);
        Swal.fire("Eliminado", "El TyC ha sido eliminado.", "success");
        getTyC();
      }
    });
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center">Términos y Condiciones</h2>
      <div className="text-end mb-3">
        <Link to="/crtTyC" className="btn bg__fond_form text-white fw-bold">Agregar TyC</Link>
      </div>
      <table className="table table-bordered">
        <thead className="table-dark">
          <tr>
            <th>Contenido</th>
            <th>Fecha de Creación</th>
            <th>Operaciones</th>
          </tr>
        </thead>
        <tbody>
          {tyc.map((item) => (
            <tr key={item._id}>
              <td>
              {item.contenido.length > 80
                  ? item.contenido.slice(0, 80) + "..."
                  : item.contenido}
              </td>
              <td>{new Date(item.fechaCreacion).toLocaleDateString()}</td>
              <td>
                <Link to={`/edtTyC/${item._id}`} className="btn btn-warning btn-sm me-2">Editar</Link>
                <button onClick={() => handleDelete(item._id)} className="btn btn-danger btn-sm">Eliminar</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default ViewTyC;
