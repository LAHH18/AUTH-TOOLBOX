import axios from "./axios";

export const sincVentana = (vent) => axios.post('/',vent)