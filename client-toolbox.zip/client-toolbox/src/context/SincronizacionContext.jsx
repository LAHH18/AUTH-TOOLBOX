import { createContext, useContext, useState } from "react";
import { getSincronizacionesRequest, addSincronizacionRequest, removeSincronizacionRequest } from "../api/sincro.js";
import Swal from "sweetalert2";

const SincronizacionContext = createContext();

export const useSincronizacion = () => {
  const context = useContext(SincronizacionContext);
  if (!context) {
    throw new Error("useSincronizacion debe usarse dentro de un SincronizacionProvider");
  }
  return context;
};

export function SincronizacionProvider({ children }) {
  const [sincronizaciones, setSincronizaciones] = useState([]);
  const [loading, setLoading] = useState(false);

  // Obtener las sincronizaciones de un usuario
  const getSincronizaciones = async (email) => {
    if (!email || loading) return;
    setLoading(true);
    try {
      const res = await getSincronizacionesRequest(email);
      setSincronizaciones(res.data);
    } catch (error) {
      console.error("Error al obtener sincronizaciones:", error);
      setSincronizaciones([]);
      Swal.fire({
        title: "Error al obtener sincronizaciones",
        text: error.response ? error.response.data.message : "Error desconocido",
        icon: "error",
        confirmButtonText: "Entendido",
      });
    } finally {
      setLoading(false);
    }
  };

  // Agregar una sincronización y actualizar la lista
  const addSincronizacion = async (email, codigoVentana, nombre) => {
    try {
      await addSincronizacionRequest(email, codigoVentana, nombre);
      getSincronizaciones(email); // Refresca la lista después de agregar
    } catch (error) {
      console.error("Error al agregar sincronización:", error);

      // Mostrar el error usando SweetAlert2
      Swal.fire({
        title: "Error al agregar sincronización",
        text: error.response ? error.response.data.message : "No se pudo agregar la sincronización.",
        icon: "error",
        confirmButtonText: "Entendido",
      });
    }
  };

  // Eliminar una sincronización y actualizar la lista
  const removeSincronizacion = async (email, codigoVentana) => {
    try {
      await removeSincronizacionRequest(email, codigoVentana);
      setSincronizaciones((prevSincronizaciones) =>
        prevSincronizaciones.filter((sync) => sync.ventana.codigo !== codigoVentana)
      );
    } catch (error) {
      console.error("Error al eliminar sincronización:", error);
      Swal.fire({
        title: "Error al eliminar sincronización",
        text: error.response ? error.response.data.message : "No se pudo eliminar la sincronización.",
        icon: "error",
        confirmButtonText: "Entendido",
      });
    }
  };

  return (
    <SincronizacionContext.Provider
      value={{
        sincronizaciones,
        getSincronizaciones,
        addSincronizacion,
        removeSincronizacion,
        loading,
      }}
    >
      {children}
    </SincronizacionContext.Provider>
  );
}
