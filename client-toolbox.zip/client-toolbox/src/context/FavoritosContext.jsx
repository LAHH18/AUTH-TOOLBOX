import { createContext, useContext, useState } from "react";
import {
  getFavoritesRequest,
  addFavoriteRequest,
  removeFavoriteRequest,
} from "../api/favoritos.js";

import {
  getCartRequest,
  addCartRequest,
  removeCartRequest,
} from "../api/carrito.js";

const FavContext = createContext();

export const useFavorites = () => {
  const context = useContext(FavContext);
  if (!context) {
    throw new Error("useFavorites debe usarse dentro de un FavoritesProvider");
  }
  return context;
};

export function FavoritesProvider({ children }) {
  const [favorites, setFavorites] = useState([]);
  const [loading, setLoading] = useState(false);
  const [carrito, setCarrito] = useState([]);
  const [loadingCar, setLoadingCar] = useState(false);

  // Obtener los favoritos del usuario
  const getFavorites = async (email) => {
    if (!email || loading) return;
    setLoading(true);
    try {
      const res = await getFavoritesRequest(email);
      setFavorites(res.data);
    } catch (error) {
      console.error("Error al obtener favoritos:", error);
      setFavorites([]);
    } finally {
      setLoading(false);
    }
  };

  // Agregar un producto a favoritos y actualizar la lista
  const addFavorite = async (email, codigoProducto) => {
    try {
      await addFavoriteRequest(email, codigoProducto);
      getFavorites(email); // Refresca la lista después de agregar
    } catch (error) {
      console.error("Error al agregar favorito:", error);
    }
  };

  // Eliminar un producto de favoritos y actualizar la lista
  const removeFavorite = async (email, codigoProducto) => {
    try {
      await removeFavoriteRequest(email, codigoProducto);
      
      //  Actualiza el estado eliminando el producto manualmente
      setFavorites((prevFavorites) => 
        prevFavorites.filter((fav) => fav.producto.codigo !== codigoProducto)
      );
    } catch (error) {
      console.error("Error al eliminar favorito:", error);
    }
  };

  //Obtener el carrito del usuario
  const getCarrito = async (email) => {
    if (!email || loadingCar) return;
    setLoadingCar(true);
    try {
      const res = await getCartRequest(email);
      setCarrito(res.data);
    } catch (error) {
      console.error("Error al obtener el carrito:", error);
      setCarrito([]);
    } finally {
      setLoadingCar(false);
    }
  };

  // Agregar un producto al carrito y actualizar la lista
  const addCart = async (email, codigoProducto, cantidad = 1) => {
    try {
      await addCartRequest(email, codigoProducto, cantidad);
      await getCarrito(email); 
    } catch (error) {
      console.error("Error al agregar al carrito:", error);
    }
  };

  //Eliminar un producto del carrito y actualizar la lista
  const removeCart = async (email, codigoProducto) => {
    try {
      await removeCartRequest(email, codigoProducto);
      setCarrito((prevCarrito) =>
        prevCarrito.filter((item) => item.producto.codigo !== codigoProducto)
      );
    } catch (error) {
      console.error("Error al eliminar del carrito:", error);
    }
  };


  return (
    <FavContext.Provider
    value={{
      favorites,
      getFavorites,
      addFavorite,
      removeFavorite,
      setFavorites,
      loading,  
      carrito,
      getCarrito,
      addCart,
      removeCart,
      setCarrito,
      loadingCar, 
    }}
    >
      {children}
    </FavContext.Provider>
  );
}
