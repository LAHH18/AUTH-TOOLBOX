import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { useEmpresaFaq } from "../context/dtsEmpContext.jsx";
import "./Header.css";
import NavBarOpt from "./Navbar.jsx";
import NavBarEmp from "./NavbarEmpleado.jsx";
import NavBarAdmin from "./NavBarAdmin.jsx";
import { FaShoppingCart } from "react-icons/fa";

function Header() {
  const { user, isAuthenticated, logout } = useAuth();
  const { empresa, getEmpresa } = useEmpresaFaq();
  const [nombreEmpresa, setNombreEmpresa] = useState("ToolBox");

  useEffect(() => {
    getEmpresa();
  }, []);

  useEffect(() => {
    if (empresa?.nombre) {
      setNombreEmpresa(empresa.nombre);
    }
  }, [empresa]);

  return (
    <>
      <nav className="navbar navbar-expand-lg p-3">
        <div className="container-fluid">
          {isAuthenticated ? (
            user.rol === 1 ? (
              <Link className="navbar-brand fs-3" to="/HomePagePriv">
                {nombreEmpresa}
              </Link>
            ) : user.rol === 3 ? (
              <Link className="navbar-brand fs-3" to="/HomeEmpleados">
                {nombreEmpresa}
              </Link>
            ) : (
              <Link className="navbar-brand fs-3" to="/">
                {nombreEmpresa}
              </Link>
            )
          ) : (
            <Link className="navbar-brand fs-3" to="/">
              {nombreEmpresa}
            </Link>
          )}

          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSearchAuth"
            aria-controls="navbarSearchAuth"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className="collapse navbar-collapse justify-content-end" id="navbarSearchAuth">
            {(!isAuthenticated || (user.rol !== 1 && user.rol !== 3)) && (
              <form className="d-flex me-auto mt-2 mt-lg-0">
                <input
                  className="form-control me-2"
                  type="search"
                  placeholder="Buscar producto"
                  aria-label="Buscar"
                />
              </form>
            )}

            <ul className="navbar-nav">
              <li className="nav-item dropdown">
                {isAuthenticated ? (
                  <>
                    <a
                      className="nav-link dropdown-toggle text-white"
                      href="#"
                      id="profileDropdown"
                      role="button"
                      data-bs-toggle="dropdown"
                      aria-expanded="false"
                    >
                      {user.username}
                    </a>
                    <ul className="dropdown-menu bg__fondo" aria-labelledby="profileDropdown">
                      <li>
                        <Link className="dropdown-item" to="/profile">Perfil</Link>
                      </li>
                      {user.rol === 2 && (
                        <>
                          <li>
                            <Link className="dropdown-item" to={`/favoritos/${user.email}`}>Favoritos</Link>
                          </li>
                          <li>
                            <Link className="dropdown-item" to="/controlVentana">IoT</Link>
                          </li>
                        </>
                      )}
                      <li>
                        <hr className="dropdown-divider" />
                      </li>
                      <li>
                        <Link className="dropdown-item" to="/" onClick={() => logout()}>
                          Cerrar sesión
                        </Link>
                      </li>
                    </ul>
                  </>
                ) : (
                  <Link className="nav-link text-white" to="/login">Iniciar Sesión</Link>
                )}
              </li>
              {isAuthenticated && user.rol === 2 ? (
                <li className="nav-item">
                  <Link to={`/carrito/${user.email}`} className="nav-link text-white position-relative">
                    <FaShoppingCart size={24} />
                  </Link>
                </li>
              ) : null}
            </ul>
          </div>
        </div>
      </nav>

      {isAuthenticated ? (
        user.rol === 1 ? <NavBarAdmin /> : user.rol === 3 ? <NavBarEmp /> : <NavBarOpt />
      ) : (
        <NavBarOpt />
      )}
    </>
  );
}

export default Header;
