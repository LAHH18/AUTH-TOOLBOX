import { Link } from 'react-router-dom';

function NavBarAdmin() {
  return (
<nav className="navbar navbar-expand-lg">
        <div className="container-fluid">
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarMainMenu"
            aria-controls="navbarMainMenu"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarMainMenu">
            <ul className="navbar-nav d-flex w-100 justify-content-between">
              <li className="nav-item">
                <Link className="nav-link" to="/HomePagePriv">Inicio</Link>
              </li>

              <li className="nav-item">
                <Link className="nav-link" to="/datosEmpresa">Datos Empresa</Link>
              </li>

              <li className="nav-item">
                <Link className="nav-link" to="/tblFAQ">Preguntas y Respuestas</Link>
              </li>
              
              <li className="nav-item">
                <Link className="nav-link" to="/tblTyC">Terminos y Condiciones</Link>
              </li>

              <li className="nav-item">
                <Link className="nav-link" to="/tblPoliticas">Politicas</Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
  )
}

export default NavBarAdmin
